﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Security.Principal;
using System.Threading.Channels;
using Microsoft.Build.Locator;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Formatting;
using Microsoft.CodeAnalysis.MSBuild;
//using Microsoft.CodeAnalysis.CSharp;
//using Microsoft.CodeAnalysis.CSharp.Syntax;
//using Microsoft.CodeAnalysis.Formatting;
//using Microsoft.CodeAnalysis.MSBuild;

namespace RoslynExploratoryLog
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            // TODO: what .csproj types does this support?
            // TODO: what C# syntax is supported by API?
            /*
             * Requirements:
             * 
             */

            /*
                1. Load the Project: Use Roslyn's MSBuildWorkspace to load the project from the given file path.
                2. Identify Relevant Classes: Loop through all classes in the project, filtering them based on your _classFilter list.
                3. Modify Methods and Properties: For each relevant class, modify all methods and property accessors to include the logging statement at the beginning.
                4. Save Changes: After modifying the syntax tree, save the changes back to the source files.
            */

            var solutionPath = @"C:\repos\spectre.console\src\Spectre.Console.sln";


            // Before creating the workspace
            if (!MSBuildLocator.IsRegistered)
            {
                MSBuildLocator.RegisterDefaults();
            }

            var workspace = MSBuildWorkspace.Create();

            var solution = await workspace.OpenSolutionAsync(solutionPath);

            //var projFilePath = @"C:\repos\spectre.console\src\Spectre.Console.Cli\Spectre.Console.Cli.csproj";
            var _classFilter = new List<string> { "CommandApp", "SomeNonExistingClassname" }; // Add your class names here
            foreach (var project in solution.Projects)
            {


                //var project = await workspace.OpenProjectAsync(projFilePath);
                foreach (var document in project.Documents)
                {
                    var syntaxRoot = await document.GetSyntaxRootAsync();
                    var semanticModel = await document.GetSemanticModelAsync();

                    // Only process classes in the filter
                    var classes = syntaxRoot.DescendantNodes()
                        .OfType<ClassDeclarationSyntax>()
                        .Where(c => _classFilter.Contains(c.Identifier.ValueText));

                    foreach (var classDeclaration in classes)
                    {
                        var members = classDeclaration.Members;
                        var newMembers = SyntaxFactory.List<MemberDeclarationSyntax>();

                        foreach (var member in members)
                        {
                            var modifiedMember = member;

                            // Modify methods
                            if (member is MethodDeclarationSyntax method)
                            {
                                modifiedMember = ModifyMethod(method, semanticModel);
                            }
                            // Modify property getters and setters
                            else if (member is PropertyDeclarationSyntax property)
                            {
                                modifiedMember = ModifyProperty(property, semanticModel);
                            }

                            newMembers = newMembers.Add(modifiedMember);
                        }

                        // Replace the class members with the new ones
                        var newClass = classDeclaration.WithMembers(newMembers);
                        syntaxRoot = syntaxRoot.ReplaceNode(classDeclaration, newClass);

                        // Apply formatting to the updated syntax tree
                        var formattedRoot = Formatter.Format(syntaxRoot, workspace);

                        // Save changes back to the document
                        var updatedDocument = document.WithSyntaxRoot(formattedRoot);
                        var text = await updatedDocument.GetTextAsync();
                        System.IO.File.WriteAllText(document.FilePath, text.ToString());
                    }
                }
            }
        }

        private static MethodDeclarationSyntax ModifyMethod(MethodDeclarationSyntax method, SemanticModel semanticModel)
        {            
            // GOOD: output will be this string->   Console.WriteLine($"{DateTime.Now}: Entering RunAsync");
            var loggingStatement = SyntaxFactory.ParseStatement($"Console.WriteLine($\"{{DateTime.Now}}: Entering {method.Identifier.ValueText}\");{Environment.NewLine}");            
            //.WithLeadingTrivia(SyntaxFactory.Whitespace(Environment.NewLine))
            //.WithTrailingTrivia(SyntaxFactory.Whitespace(Environment.NewLine));
            var newBody = method.Body.WithStatements(method.Body.Statements.Insert(0, loggingStatement));
            return method.WithBody(newBody);
        }

        private static PropertyDeclarationSyntax ModifyProperty(PropertyDeclarationSyntax property, SemanticModel semanticModel)
        {
            // Prepare the logging statement for insertion.
            // Note: Property accessors don't have their own identifiers, so we use the property's identifier.
            // Good: output-> Console.WriteLine("${DateTime.Now}: Entering DumbProp1 - Getter");
            var logStatementTemplate = "Console.WriteLine(\"${0}: Entering {1}\");" + Environment.NewLine;            

            // Modify the getter, if it exists
            var getter = property.AccessorList.Accessors.FirstOrDefault(a => a.Keyword.ValueText == "get");
            if (getter != null && getter.Body != null)
            {
                var logStatement = SyntaxFactory.ParseStatement(string.Format(logStatementTemplate, "{DateTime.Now}", $"{property.Identifier.ValueText} - Getter"));
                    //.WithLeadingTrivia(SyntaxFactory.Whitespace(Environment.NewLine))
                    //.WithTrailingTrivia(SyntaxFactory.Whitespace(Environment.NewLine));
                var newGetterBody = getter.Body.WithStatements(getter.Body.Statements.Insert(0, logStatement));
                getter = getter.WithBody(newGetterBody);
            }

            // Modify the setter, if it exists
            var setter = property.AccessorList.Accessors.FirstOrDefault(a => a.Keyword.ValueText == "set");
            if (setter != null && setter.Body != null)
            {
                var logStatement = SyntaxFactory.ParseStatement(string.Format(logStatementTemplate, "{DateTime.Now}", $"{property.Identifier.ValueText} - Setter"));
                    //.WithLeadingTrivia(SyntaxFactory.Whitespace(Environment.NewLine))
                    //.WithTrailingTrivia(SyntaxFactory.Whitespace(Environment.NewLine));
                var newSetterBody = setter.Body.WithStatements(setter.Body.Statements.Insert(0, logStatement));
                setter = setter.WithBody(newSetterBody);
            }

            // Reconstruct the property with modified accessors.
            var newAccessors = property.AccessorList.Accessors
                .Select(a => a.Keyword.ValueText == "get" ? getter : (a.Keyword.ValueText == "set" ? setter : a))
                .ToArray();

            var newAccessorList = SyntaxFactory.AccessorList(SyntaxFactory.List(newAccessors));
            return property.WithAccessorList(newAccessorList);
        }
    }
}